﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' La información general sobre un ensamblado se controla mediante el siguiente 
' conjunto de atributos. Cambie estos atributos para modificar la información
' asociada con un ensamblado.

' Revisar los valores de los atributos del ensamblado

<Assembly: AssemblyTitle("AjpdSoft Convertir texto a PDF")> 
<Assembly: AssemblyDescription("AjpdSoft Convertir texto a PDF")> 
<Assembly: AssemblyCompany("Proyecto AjpdSoft")> 
<Assembly: AssemblyProduct("AjpdSoft Convertir texto a PDF")> 
<Assembly: AssemblyCopyright("http://www.ajpdsoft.com Proyecto AjpdSoft, Copyright ©  2012")> 
<Assembly: AssemblyTrademark("Proyecto AjpdSoft")> 

<Assembly: ComVisible(False)>

'El siguiente GUID sirve como identificador de typelib si este proyecto se expone a COM
<Assembly: Guid("b05d0261-0001-4595-b284-529e67579f87")> 

' La información de versión de un ensamblado consta de los cuatro valores siguientes:
'
'      Versión principal
'      Versión secundaria 
'      Número de compilación
'      Revisión
'
' Puede especificar todos los valores o usar los valores predeterminados de número de compilación y de revisión 
' mediante el asterisco ('*'), como se muestra a continuación:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
