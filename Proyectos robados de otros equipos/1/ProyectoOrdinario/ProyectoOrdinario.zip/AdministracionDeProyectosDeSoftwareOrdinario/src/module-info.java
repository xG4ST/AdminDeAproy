module administracionDeProyectosDeSoftware {
	requires itext;
	requires opencsv;
	requires java.desktop;
	requires java.base;
	
	requires ProgramaAdmin;
	requires org.bouncycastle.pkix;
	requires jPDFSecure;
}